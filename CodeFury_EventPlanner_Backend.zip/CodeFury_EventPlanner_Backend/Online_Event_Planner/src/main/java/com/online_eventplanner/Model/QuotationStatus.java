package com.online_eventplanner.Model;

public enum QuotationStatus {
	PENDING, ACCEPTED, REJECTED;

	public String getStatus() {
		// TODO Auto-generated method stub
		return null;
	}

}
