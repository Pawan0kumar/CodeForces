package com.online_eventplanner.Impl;

import com.online_eventplanner.Business.EventService;
import com.online_eventplanner.Dao.EventDao;
import com.online_eventplanner.Dao.UserDao;
import com.online_eventplanner.Dao.VendorDao;
import com.online_eventplanner.Exception.CustomException;
import com.online_eventplanner.Model.Event;
import com.online_eventplanner.Model.QuotationRequest;
import com.online_eventplanner.Model.QuotationResponse;
import com.online_eventplanner.Model.Vendor;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.List;
import java.util.Properties;

public class UserEventServiceImpl implements EventService {
	private EventDao eventDao;
	private VendorDao vendorDao;

	public UserEventServiceImpl(EventDao eventDao, UserDao userDao, VendorDao vendorDao) {
		this.eventDao = eventDao;
		this.vendorDao = vendorDao;
	}

	public Event createEvent(Event event) throws SQLException, IOException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Event createdEvent = null;

		try {
			// Obtain a database connection here
			connection = getDatabaseConnection();

			String insertQuery = "INSERT INTO event (event_name, event_location, event_date, event_time, event_price, vendor_id) VALUES (?, ?, ?, ?, ?, ?)";

			preparedStatement = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
			preparedStatement.setString(1, event.getEventName());
			preparedStatement.setString(2, event.getEventLocation());
			preparedStatement.setDate(3, Date.valueOf(event.getEventDate()));
			preparedStatement.setTime(4, Time.valueOf(event.getEventTime() + ":00")); // Append ":00" for seconds
			preparedStatement.setBigDecimal(5, event.getEventPrice());
			preparedStatement.setInt(6, event.getVendorId());

			int affectedRows = preparedStatement.executeUpdate();

			if (affectedRows == 0) {
				throw new SQLException("Creating event failed, no rows affected.");
			}

			try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
				if (generatedKeys.next()) {
					int eventId = generatedKeys.getInt(1);
					createdEvent = new Event(eventId, event.getEventName(), event.getEventLocation(),
							event.getEventDate(), event.getEventTime(), event.getEventPrice(),event.getVendorId());
				} else {
					throw new SQLException("Creating event failed, no ID obtained.");
				}
			}
		} catch (SQLException e) {
			// Log the exception and handle it appropriately
			e.printStackTrace(); // Replace with proper logging
			throw e; // Re-throw the exception for higher-level handling
		} finally {
			// Close the resources (connection, preparedStatement, resultSet) here
			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (SQLException e) {
					e.printStackTrace(); // Replace with proper logging
				}
			}
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace(); 
				}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace(); 
				}
			}
		}

		return createdEvent;
	}

	private Connection getDatabaseConnection() throws SQLException, IOException {
		Properties dbProperties = loadDbProperties();
		return DriverManager.getConnection(dbProperties.getProperty("db.url"), dbProperties.getProperty("db.user"),
				dbProperties.getProperty("db.password"));
	}

	private Properties loadDbProperties() throws IOException {
		Properties properties = new Properties();
		try (InputStream input = getClass().getClassLoader().getResourceAsStream("db.properties")) {
			properties.load(input);
		}
		return properties;
	}

	public Event updateEvent(Event event) {
		return eventDao.updateEvent(event);
	}

	public Event getEventById(int eventId) {
		return eventDao.getEventById(eventId);
	}

	public List<Event> getAllEvents() {
		return eventDao.getAllEvents();
	}

	public void deleteEvent(int eventId) {
		eventDao.deleteEvent(eventId);
	}

	public QuotationRequest generateQuotation(int eventId, int userId, String message) {
		Event event = eventDao.getEventById(eventId);
		Vendor vendor = findVendorForEvent(event);

		if (vendor == null) {
			throw new CustomException("Vendor not found for the specified event.");
		}

		QuotationRequest quotationRequest = new QuotationRequest();
		// You can add additional details to the quotation request if needed

		return quotationRequest;
	}

	private Vendor findVendorForEvent(Event event) {
		// Implement logic to find a vendor for the specified event based on event

		// For demonstration purposes, let's assume a vendor is found with ID 1
		Vendor vendor = vendorDao.getVendorById(1);

		return vendor;
	}

	@Override
	public QuotationResponse handleQuotationRequest(QuotationRequest quotationRequest) throws CustomException {
		// Find the vendor for the specified event
		Vendor vendor = findVendorForEvent(quotationRequest.getEventId());

		if (vendor == null) {
			throw new CustomException("Vendor not found for the specified event.");
		}

		// Simulate generating a quotation response
		QuotationResponse quotationResponse = new QuotationResponse(null, 0, false);
		quotationResponse.setVendorName(vendor.getVendorName());
		quotationResponse.setPrice(500.0); // Simulated price
		quotationResponse.setAvailability("Available"); // Simulated availability

		return quotationResponse;
	}

	@Override
	public QuotationResponse generateQuotation(QuotationRequest quotationRequest) {
		// TODO Auto-generated method stub
		return null;
	}

}
