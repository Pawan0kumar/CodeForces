package com.online_eventplanner.Model;


public class User implements Account {
 private int userId;
 private String userPhone;

 public User(int userId, String username, String email, String password, String userPhone) {
     this.userId = userId;
     this.userPhone = userPhone;
 }

public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}

public String getUserPhone() {
	return userPhone;
}

public void setUserPhone(String userPhone) {
	this.userPhone = userPhone;
}

public void setUsername(String username) {
}

public void setEmail(String email) {
}

public void setPassword(String password) {
}

public int getId() {
	// TODO Auto-generated method stub
	return 0;
}

public String getUsername() {
	// TODO Auto-generated method stub
	return null;
}

public String getEmail() {
	// TODO Auto-generated method stub
	return null;
}

public String getPassword() {
	// TODO Auto-generated method stub
	return null;
}





}


