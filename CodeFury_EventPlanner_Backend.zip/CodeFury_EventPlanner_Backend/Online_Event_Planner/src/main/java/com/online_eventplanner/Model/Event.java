package com.online_eventplanner.Model;

import java.math.BigDecimal;

public class Event {
    private int eventId;
    private String eventName;
    private String eventLocation;
    private String eventDate;
    private String eventTime;
    private BigDecimal eventPrice;
    private int vendorId;

    public Event(int eventId, String eventName, String eventLocation, String eventDate, String eventTime, BigDecimal eventPrice, int vendorId) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.eventLocation = eventLocation;
        this.eventDate = eventDate;
        this.eventTime = eventTime;
        this.eventPrice = eventPrice;
        this.vendorId = vendorId;
    }

    // Getters and Setters

    public Event(int eventId2, String eventName2, String eventLocation2, String string, String string2,
			double eventPrice2, int vendorId2) {
		// TODO Auto-generated constructor stub
	}

	public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventLocation() {
        return eventLocation;
    }

    public void setEventLocation(String eventLocation) {
        this.eventLocation = eventLocation;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }

    public BigDecimal getEventPrice() {
        return eventPrice;
    }

    public void setEventPrice(BigDecimal eventPrice) {
        this.eventPrice = eventPrice;
    }

    public int getVendorId() {
        return vendorId;
    }

    public void setVendorId(int vendorId) {
        this.vendorId = vendorId;
    }

    // Override toString method for better representation
    @Override
    public String toString() {
        return "Event{" +
                "eventId=" + eventId +
                ", eventName='" + eventName + '\'' +
                ", eventLocation='" + eventLocation + '\'' +
                ", eventDate='" + eventDate + '\'' +
                ", eventTime='" + eventTime + '\'' +
                ", eventPrice=" + eventPrice +
                ", vendorId=" + vendorId +
                '}';
    }

    // Override hashCode and equals methods if needed
    @Override
    public int hashCode() {
        // Implement hash code generation logic here
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        // Implement equals method logic here
        return super.equals(obj);
    }

    // Other methods can be added as needed
}
