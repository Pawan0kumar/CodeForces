package com.online_eventplanner.Business;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.online_eventplanner.Exception.CustomException;
import com.online_eventplanner.Exception.InvalidQuotationResponseException;
import com.online_eventplanner.Exception.QuotationRequestException;
import com.online_eventplanner.Model.Event;
import com.online_eventplanner.Model.QuotationRequest;
import com.online_eventplanner.Model.QuotationResponse;

public interface EventService {
	Event createEvent(Event event) throws CustomException, SQLException, IOException;

	Event updateEvent(Event event);

	Event getEventById(int eventId);

	List<Event> getAllEvents();

	void deleteEvent(int eventId);

	QuotationRequest generateQuotation(int eventId, int userId, String message) throws QuotationRequestException, InvalidQuotationResponseException;

	com.online_eventplanner.Model.QuotationResponse generateQuotation(QuotationRequest quotationRequest);

	QuotationResponse handleQuotationRequest(QuotationRequest quotationRequest);

	// Additional methods for event-related operations, for future
}
