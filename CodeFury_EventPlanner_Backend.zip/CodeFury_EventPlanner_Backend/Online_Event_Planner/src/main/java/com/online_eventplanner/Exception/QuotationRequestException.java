package com.online_eventplanner.Exception;

public class QuotationRequestException extends Exception {
    public QuotationRequestException(String message) {
        super("sorry, try again, invalis Quotation request");
    }
}

