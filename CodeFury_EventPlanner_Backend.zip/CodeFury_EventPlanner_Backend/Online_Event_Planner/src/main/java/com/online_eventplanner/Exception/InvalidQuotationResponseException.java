package com.online_eventplanner.Exception;

public class InvalidQuotationResponseException extends Exception {
    public InvalidQuotationResponseException(String message) {
        super("sorry try again, invalid Quotation response");
    }
}
