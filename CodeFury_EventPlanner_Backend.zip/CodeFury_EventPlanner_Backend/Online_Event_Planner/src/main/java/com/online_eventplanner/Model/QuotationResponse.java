package com.online_eventplanner.Model;

public class QuotationResponse {
    private String vendorName;
    private double price;
    private String availability;

    public QuotationResponse(String vendorName, double price, String b) {
        this.vendorName = vendorName;
        this.price = price;
        this.availability = b;
    }

    public QuotationResponse(Object vendorName2, int price2, boolean b) {
		// TODO Auto-generated constructor stub
	}

	public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String string) {
        this.availability = string;
    }
}
