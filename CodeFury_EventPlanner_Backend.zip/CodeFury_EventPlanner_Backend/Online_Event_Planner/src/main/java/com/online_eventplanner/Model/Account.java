package com.online_eventplanner.Model;

public interface Account {
	int getId();
    String getUsername();
    String getEmail();
    String getPassword();
}
