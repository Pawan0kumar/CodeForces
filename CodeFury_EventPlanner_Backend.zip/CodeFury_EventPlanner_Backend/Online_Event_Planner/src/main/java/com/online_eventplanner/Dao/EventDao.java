package com.online_eventplanner.Dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.online_eventplanner.Model.Event;

public interface EventDao {
	Event createEvent(Event event) throws SQLException, IOException;

	Event updateEvent(Event event);

	Event getEventById(int eventId);

	List<Event> getAllEvents();

	void deleteEvent(int eventId);

	 void generateQuotation(int eventId, int userId, String message);
}
