package com.online_eventplanner.Model;

public class Vendor implements Account {
	private int vendorId;
	private String username;
	private String email;
	private String password;
	private String companyName; // Additional attribute for vendors
	private String contactNumber; // Additional attribute for vendors

	// Constructors
	public Vendor() {
		// Default constructor
	}

	public Vendor(int vendorId, String username, String email, String password, String companyName,
			String contactNumber) {
		this.vendorId = vendorId;
		this.username = username;
		this.email = email;
		this.password = password;
		this.companyName = companyName;
		this.contactNumber = contactNumber;
	}

	// Getters and setters for the attributes
	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getVendorName() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
