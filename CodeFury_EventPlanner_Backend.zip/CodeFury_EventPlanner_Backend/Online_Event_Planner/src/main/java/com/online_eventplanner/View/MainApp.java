package com.online_eventplanner.View;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.online_eventplanner.Business.EventService;
import com.online_eventplanner.Dao.EventDao;
import com.online_eventplanner.Dao.EventDaoImpl;
import com.online_eventplanner.Dao.UserDao;
import com.online_eventplanner.Dao.UserDaoImpl;
import com.online_eventplanner.Dao.VendorDao;
import com.online_eventplanner.Dao.VendorDaoImpl;
import com.online_eventplanner.Exception.CustomException;
import com.online_eventplanner.Impl.UserEventServiceImpl;
import com.online_eventplanner.Model.Event;
import com.online_eventplanner.Model.QuotationResponse;

public class MainApp {
    public static void main(String[] args) throws SQLException, IOException {
        // Create instances of DAO implementation classes
        EventDao eventDao = new EventDaoImpl();
        UserDao userDao = new UserDaoImpl();
        VendorDao vendorDao = new VendorDaoImpl();

        // Create an instance of the service class with DAOs
        EventService userEventService = new UserEventServiceImpl(eventDao, userDao, vendorDao);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Options:");
            System.out.println("1. Create Event");
            System.out.println("2. Request Quotation");
            System.out.println("3. Exit");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    Event event = createEvent(scanner);
                    if (event != null) {
                        try {
                            Event createdEvent = userEventService.createEvent(event);
                            System.out.println("Event created Successfully: " + createdEvent);
                        } catch (CustomException e) {
                            System.err.println("Event creation error: " + e.getMessage());
                        }
                    }
                    break;
                case 2:
               
                    QuotationResponse quotationResponse = requestQuotation(scanner);
                    // Display the quotation response or perform further actions as needed
                    System.out.println("Vendor Name: " + quotationResponse.getVendorName());
                    System.out.println("Price: " + quotationResponse.getPrice());
                    System.out.println("Availability: " + quotationResponse.getAvailability());
                    break;
                case 3:
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option. Please select a valid option.");
            }
        }
    }

    private static Event createEvent(Scanner scanner) {
        System.out.print("Enter event name: ");
        String name = scanner.nextLine();
        System.out.print("Enter event location: ");
        String location = scanner.nextLine();
        System.out.print("Enter event date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter event time (HH:MM): ");
        String time = scanner.nextLine();
        if (!isValidTimeFormat(time)) {
            System.err.println("Invalid time format. Please use HH:MM format.");
            return null;
        }
        System.out.print("Enter event price: ");
        double price = 0.0;
        try {
            price = scanner.nextDouble();
            scanner.nextLine();
        } catch (InputMismatchException e) {
            System.err.println("Invalid price format. Please enter a valid numeric value.");
            scanner.nextLine(); // Consume the invalid input
            return null;
        }
        System.out.print("Enter vendor ID: ");
        int vendorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Create an Event object with the provided values
        return new Event(0, name, location, date, time, BigDecimal.valueOf(price), vendorId);
    }

    private static boolean isValidTimeFormat(String time) {
        // Regular expression for time checking
        return time.matches("\\d{2}:\\d{2}");
    }

    private static QuotationResponse requestQuotation(Scanner scanner) {
        System.out.print("Enter your message for quotation request: ");
        scanner.nextLine();
        System.out.print("Enter your event ID: ");
        scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Simulate gathering user information
        System.out.print("Enter your user ID: ");
        scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter your name: ");
        scanner.nextLine();
        System.out.print("Enter your email: ");
        scanner.nextLine();
        
        // In a real scenario, you would gather quotation details from the vendor here.
        // For demonstration, let's create a sample response.
        String vendorName = "Bhupandra singh";
        double price = 50000.0;
        String availability = "Available";

        System.out.println("Quotation request sent Successfully \n");
        System.out.println("The vendor will contact you \n");

        // Create and return a QuotationResponse
        return new QuotationResponse(vendorName, price, availability);
    }

}
