package com.online_eventplanner.Dao;

import com.online_eventplanner.Model.Vendor;
import com.online_eventplanner.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VendorDaoImpl implements VendorDao {
    // Define SQL queries here
    private static final String GET_VENDOR_BY_ID_SQL = "SELECT * FROM Vendors WHERE vendor_id = ?";
    private static final String GET_ALL_VENDORS_SQL = "SELECT * FROM Vendors";

    @Override
    public Vendor getVendorById(int vendorId) {
        try (Connection connection = DBUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(GET_VENDOR_BY_ID_SQL)) {
            preparedStatement.setInt(1, vendorId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    // Create and return the Vendor object
                    return extractVendorFromResultSet(resultSet);
                } else {
                    return null; // Vendor not found
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null; // Error occurred
        }
    }

    public List<Vendor> getAllVendors() {
        List<Vendor> vendorList = new ArrayList<>();
        try (Connection connection = DBUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(GET_ALL_VENDORS_SQL);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                Vendor vendor = extractVendorFromResultSet(resultSet);
                vendorList.add(vendor);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return vendorList;
    }

    // Utility method to extract a Vendor object from a ResultSet
    private Vendor extractVendorFromResultSet(ResultSet resultSet) throws SQLException {
        int vendorId = resultSet.getInt("vendor_id");
        String name = resultSet.getString("name");
        String email = resultSet.getString("email");
        String phone = resultSet.getString("phone");
        String location = resultSet.getString("location");
        return new Vendor(vendorId, name, email, phone, location, location);
    }

	@Override
	public Vendor createVendor(Vendor vendor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vendor updateVendor(Vendor vendor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vendor getVendorByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteVendor(int vendorId) {
		// TODO Auto-generated method stub
		
	}

}
