package com.online_eventplanner.Dao;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.online_eventplanner.Model.Event;
import com.online_eventplanner.util.DBUtil;
	
	public class EventDaoImpl implements EventDao {

	    private static final String DB_PROPERTIES_FILE = "db.properties";
		private static final String GET_EVENT_BY_ID_SQL = null;
		private static final String GET_ALL_EVENTS_SQL = null;
		private static final String DELETE_EVENT_SQL = null;

		public Event createEvent(Event event, String vendorName) throws SQLException, IOException, ParseException {
		    Connection connection = null;
		    PreparedStatement preparedStatement = null;
		    Event createdEvent = null;

		    try {
		        Properties dbProperties = loadDbProperties();
		        connection = DriverManager.getConnection(
		            dbProperties.getProperty("db.url"),
		            dbProperties.getProperty("db.user"),
		            dbProperties.getProperty("db.password")
		        );

		        // Get the vendor_id based on vendorName (you need to implement this logic)
		        int vendorId = getVendorIdByName(vendorName, connection);

		        // Your SQL query to insert the event into the database
		        String insertQuery = "INSERT INTO event (event_name, event_location, event_date, event_time, event_price, vendor_id) VALUES (?, ?, ?, ?, ?, ?)";

		        preparedStatement = connection.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
		        preparedStatement.setString(1, event.getEventName());
		        preparedStatement.setString(2, event.getEventLocation());
		        preparedStatement.setDate(3, Date.valueOf(event.getEventDate()));
		        preparedStatement.setTime(4, Time.valueOf(event.getEventTime() + ":00")); // Append ":00" for seconds
		        preparedStatement.setBigDecimal(5, event.getEventPrice());
		        preparedStatement.setInt(6, vendorId); // Use the retrieved vendor_id

		        int affectedRows = preparedStatement.executeUpdate();

		        if (affectedRows == 0) {
		            throw new SQLException("Creating event failed, no rows affected.");
		        }

		        try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
		            if (generatedKeys.next()) {
		                int eventId = generatedKeys.getInt(1);
		                createdEvent = new Event(eventId, event.getEventName(), event.getEventLocation(), event.getEventDate(), event.getEventTime(), event.getEventPrice(),event.getVendorId());
		            } else {
		                throw new SQLException("Creating event failed, no ID obtained.");
		            }
		        }
		    } finally {
		        // Close resources and handle exceptions here if needed
		        if (preparedStatement != null) {
		            try {
		                preparedStatement.close();
		            } catch (SQLException e) {
		                e.printStackTrace(); // Replace with proper logging or error handling
		            }
		        }
		        if (connection != null) {
		            try {
		                connection.close();
		            } catch (SQLException e) {
		                e.printStackTrace(); // Replace with proper logging or error handling
		            }
		        }
		    }

		    return createdEvent;
		}

	 // Add this method to your EventDaoImpl class
	    private int getVendorIdByName(String vendorName, Connection connection) throws SQLException {
	        int vendorId = -1; // Default value if vendor is not found
	        String query = "SELECT vendor_id FROM vendors WHERE vendor_name = ?";
	        
	        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	            preparedStatement.setString(1, vendorName);
	            try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                if (resultSet.next()) {
	                    vendorId = resultSet.getInt("vendor_id");
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        if (vendorId == -1) {
	            throw new SQLException("Vendor not found with name: " + vendorName);
	        }

	        return vendorId;
	    }

	    // Load database properties from db.properties file
	    private Properties loadDbProperties() throws IOException {
	        Properties properties = new Properties();
	        try (FileReader reader = new FileReader(DB_PROPERTIES_FILE)) {
	            properties.load(reader);
	        }
	        return properties;
	    }
	

    private Event extractEventFromResultSet(ResultSet resultSet) throws SQLException {
        int eventId = resultSet.getInt("event_id");
        String eventName = resultSet.getString("event_name");
        String eventLocation = resultSet.getString("event_location");
        Date eventDate = resultSet.getDate("event_date");
        Time eventTime = resultSet.getTime("event_time");
        double eventPrice = resultSet.getDouble("event_price");
        int vendorId = resultSet.getInt("vendor_id");
        return new Event(eventId, eventName, eventLocation, eventDate.toString(), eventTime.toString(), eventPrice, vendorId);
    }




    public Event updateEvent(Event event) {
        // Implement event update logic here
        return event;
    }

    public Event getEventById(int eventId) {
        try (Connection connection = DBUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(GET_EVENT_BY_ID_SQL)) {
            preparedStatement.setInt(1, eventId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    // Create and return the Event object
                    return extractEventFromResultSet(resultSet);
                } else {
                    return null; // Event not found
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null; // Error occurred
        }
    }

    public List<Event> getAllEvents() {
        List<Event> eventList = new ArrayList<>();
        try (Connection connection = DBUtil.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(GET_ALL_EVENTS_SQL)) {
            while (resultSet.next()) {
                Event event = extractEventFromResultSet(resultSet);
                eventList.add(event);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return eventList;
    }

    public void deleteEvent(int eventId) {
        try (Connection connection = DBUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_EVENT_SQL)) {
            preparedStatement.setInt(1, eventId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void generateQuotation(int eventId, int userId, String message) {
        // Implement quotation generation logic here
        // This method is used for quotation requests, and you can handle it as needed
        return;
    }



	@Override
	public Event createEvent(Event event) throws SQLException, IOException {
		// TODO Auto-generated method stub
		return null;
	}
}
