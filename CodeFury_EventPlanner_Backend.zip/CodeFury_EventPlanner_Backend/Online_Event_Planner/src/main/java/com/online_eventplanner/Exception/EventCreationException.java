package com.online_eventplanner.Exception;

public class EventCreationException extends CustomException {
    public EventCreationException(String message) {
        super("event cannot be created");
    }
}
