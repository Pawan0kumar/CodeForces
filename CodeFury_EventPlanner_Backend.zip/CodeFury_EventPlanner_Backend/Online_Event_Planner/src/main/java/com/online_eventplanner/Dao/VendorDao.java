package com.online_eventplanner.Dao;

import com.online_eventplanner.Model.Vendor;

public interface VendorDao {
	Vendor createVendor(Vendor vendor);

	Vendor updateVendor(Vendor vendor);

	Vendor getVendorById(int vendorId);

	Vendor getVendorByEmail(String email);

	void deleteVendor(int vendorId);
}
