package com.online_eventplanner.Model;

public class Quotation {
	private int quotationId;
	private int eventId;
	private int vendorId;
	private double price;
	private boolean availability;
	// Add other attributes relevant to quotations

	// Constructors
	public Quotation() {
		// Default constructor
	}

	public Quotation(int quotationId, int eventId, int vendorId, double price, boolean availability) {
		this.quotationId = quotationId;
		this.eventId = eventId;
		this.vendorId = vendorId;
		this.price = price;
		this.availability = availability;
		// Initialize other attributes as needed
	}

	// Getters and setters for the attributes
	public int getQuotationId() {
		return quotationId;
	}

	public void setQuotationId(int quotationId) {
		this.quotationId = quotationId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public boolean isAvailability() {
		return availability;
	}

	public void setAvailability(boolean availability) {
		this.availability = availability;
	}

	// Add additional methods and attributes as needed
}
